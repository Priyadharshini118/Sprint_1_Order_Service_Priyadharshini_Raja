package Shopping_Mall;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Order_Service_Repository extends JpaRepository <Order,Integer> {

}
